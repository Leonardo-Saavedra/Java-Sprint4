package br.com.fiap.bo;

import br.com.fiap.beans.TeleConsulta;
import br.com.fiap.dao.TeleConsultaDAO;
import java.util.List;

public class TeleConsultaBO {
    private TeleConsultaDAO dao;

    public List<TeleConsulta> listar() throws Exception {
        dao = new TeleConsultaDAO();
        return dao.listar();
    }

    public TeleConsulta buscarPorId(int id) throws Exception {
        dao = new TeleConsultaDAO();
        return dao.buscarPorId(id);
    }

    public void salvar(TeleConsulta t) throws Exception {
        dao = new TeleConsultaDAO();
        dao.inserir(t);
    }

    public boolean atualizar(int id, TeleConsulta t) throws Exception {
        dao = new TeleConsultaDAO();
        return dao.atualizar(id, t);
    }

    public boolean deletar(int id) throws Exception {
        dao = new TeleConsultaDAO();
        return dao.remover(id);
    }
}
