package br.com.fiap.main;

import br.com.fiap.beans.*;
import br.com.fiap.dao.*;

public class TesteAplicacao {
    public static void main(String[] args) {
        try {
            System.out.println("=== INSERINDO REGISTROS ===");

            // -----------------------------
            // MÉDICO
            // -----------------------------
            Medico medico = new Medico(1, "Dr. João Silva", "CRM12345", "joao.silva@hospital.com");
            MedicoDAO medicoDAO = new MedicoDAO();
            medicoDAO.inserir(medico);
            System.out.println("Médico inserido com sucesso!");

            // -----------------------------
            // PACIENTE
            // -----------------------------
            Paciente paciente = new Paciente(10, "Maria Oliveira", "11999998888",
                    java.time.LocalDate.of(1990, 5, 20), medico);
            PacienteDAO pacienteDAO = new PacienteDAO();
            pacienteDAO.inserir(paciente);
            System.out.println("Paciente inserido com sucesso!");

            // -----------------------------
            // AGENDAMENTO
            // -----------------------------
            Agendamento agendamento = new Agendamento(300, "Confirmado", paciente);
            AgendamentoDAO agendamentoDAO = new AgendamentoDAO();
            agendamentoDAO.inserir(agendamento);
            System.out.println("Agendamento inserido com sucesso!");

            System.out.println("\n=== LISTANDO REGISTROS ===");
            for (Agendamento a : agendamentoDAO.listar()) {
                System.out.println(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
