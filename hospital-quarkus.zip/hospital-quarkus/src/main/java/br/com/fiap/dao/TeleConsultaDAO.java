package br.com.fiap.dao;

import br.com.fiap.beans.TeleConsulta;
import br.com.fiap.beans.Medico;
import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeleConsultaDAO {

    public int inserir(TeleConsulta t) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO teleconsulta (id_tele_consulta, ds_observacoes, id_medico) VALUES (?, ?, ?)";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, t.getId());
            ps.setString(2, t.getObservacoes());
            ps.setInt(3, t.getIdMedico());
            return ps.executeUpdate();
        }
    }

    public List<TeleConsulta> listar() throws SQLException, ClassNotFoundException {
        List<TeleConsulta> lista = new ArrayList<>();
        String sql = "SELECT id_tele_consulta, ds_observacoes, id_medico FROM teleconsulta";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                TeleConsulta t = new TeleConsulta();
                t.setId(rs.getInt("id_tele_consulta"));
                t.setObservacoes(rs.getString("ds_observacoes"));
                int idMed = rs.getInt("id_medico");
                if (!rs.wasNull()) t.setIdMedico(idMed);
                lista.add(t);
            }
        }
        return lista;
    }

    public TeleConsulta buscarPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id_tele_consulta, ds_observacoes, id_medico FROM teleconsulta WHERE id_tele_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TeleConsulta t = new TeleConsulta();
                    t.setId(rs.getInt("id_tele_consulta"));
                    t.setObservacoes(rs.getString("ds_observacoes"));
                    t.setIdMedico(rs.getInt("id_medico"));
                    return t;
                }
            }
        }
        return null;
    }

    public boolean atualizar(int id, TeleConsulta t) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE teleconsulta SET ds_observacoes = ?, id_medico = ? WHERE id_tele_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getObservacoes());
            ps.setInt(2, t.getIdMedico());
            ps.setInt(3, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean remover(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM teleconsulta WHERE id_tele_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
