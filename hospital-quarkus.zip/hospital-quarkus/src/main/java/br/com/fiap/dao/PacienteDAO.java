package br.com.fiap.dao;

import br.com.fiap.beans.Paciente;
import br.com.fiap.beans.Medico;
import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

    public int inserir(Paciente paciente) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO paciente (id_paciente, nm_paciente, num_telefone, dt_nascimento, id_medico) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, paciente.getId());
            ps.setString(2, paciente.getNome());
            ps.setString(3, paciente.getTelefone());

            if (paciente.getDataNascimento() != null) {
                ps.setDate(4, Date.valueOf(paciente.getDataNascimento()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.setInt(5, paciente.getMedico() != null ? paciente.getMedico().getId() : 0);
            return ps.executeUpdate();
        }
    }

    public List<Paciente> listar() throws SQLException, ClassNotFoundException {
        List<Paciente> lista = new ArrayList<>();
        String sql = "SELECT id_paciente, nm_paciente, num_telefone, dt_nascimento, id_medico FROM paciente";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Paciente p = new Paciente();
                p.setId(rs.getInt("id_paciente"));
                p.setNome(rs.getString("nm_paciente"));
                p.setTelefone(rs.getString("num_telefone"));

                Date d = rs.getDate("dt_nascimento");
                p.setDataNascimento(d != null ? d.toLocalDate() : null);

                int idMed = rs.getInt("id_medico");
                if (!rs.wasNull()) {
                    Medico m = new Medico();
                    m.setId(idMed);
                    p.setMedico(m);
                }
                lista.add(p);
            }
        }
        return lista;
    }

    public Paciente buscarPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id_paciente, nm_paciente, num_telefone, dt_nascimento, id_medico FROM paciente WHERE id_paciente = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Paciente p = new Paciente();
                    p.setId(rs.getInt("id_paciente"));
                    p.setNome(rs.getString("nm_paciente"));
                    p.setTelefone(rs.getString("num_telefone"));
                    Date d = rs.getDate("dt_nascimento");
                    p.setDataNascimento(d != null ? d.toLocalDate() : null);
                    int idMed = rs.getInt("id_medico");
                    if (!rs.wasNull()) {
                        Medico m = new Medico();
                        m.setId(idMed);
                        p.setMedico(m);
                    }
                    return p;
                }
            }
        }
        return null;
    }

    public boolean atualizar(int id, Paciente paciente) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE paciente SET nm_paciente = ?, num_telefone = ?, dt_nascimento = ?, id_medico = ? WHERE id_paciente = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, paciente.getNome());
            ps.setString(2, paciente.getTelefone());
            if (paciente.getDataNascimento() != null) {
                ps.setDate(3, Date.valueOf(paciente.getDataNascimento()));
            } else {
                ps.setNull(3, Types.DATE);
            }
            ps.setInt(4, paciente.getMedico() != null ? paciente.getMedico().getId() : 0);
            ps.setInt(5, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean remover(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM paciente WHERE id_paciente = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
