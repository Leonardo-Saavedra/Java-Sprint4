package br.com.fiap.resource;

import br.com.fiap.beans.Consulta;
import br.com.fiap.dao.ConsultaDAO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/consultas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ConsultaResource {

    @GET
    public Response listar() {
        try {
            ConsultaDAO dao = new ConsultaDAO();
            List<Consulta> lista = dao.listar();
            return Response.ok(lista).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao listar consultas: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            ConsultaDAO dao = new ConsultaDAO();
            Consulta consulta = dao.buscarPorId(id);
            if (consulta == null)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Consulta não encontrada.")
                        .build();
            return Response.ok(consulta).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao buscar consulta: " + e.getMessage())
                    .build();
        }
    }

    @POST
    public Response inserir(Consulta consulta) {
        try {
            ConsultaDAO dao = new ConsultaDAO();
            dao.inserir(consulta);
            return Response.status(Response.Status.CREATED)
                    .entity("Mensagem: Consulta inserida com sucesso!")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao inserir consulta: " + e.getMessage())
                    .build();
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response atualizar(@PathParam("id") int id, Consulta consulta) {
        try {
            ConsultaDAO dao = new ConsultaDAO();
            consulta.setId(id);
            boolean atualizado = dao.atualizar(id, consulta);

            if (!atualizado)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Consulta não encontrada.")
                        .build();

            return Response.ok("Mensagem: Consulta atualizada com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{Erro: Erro ao atualizar consulta: " + e.getMessage())
                    .build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response remover(@PathParam("id") int id) {
        try {
            ConsultaDAO dao = new ConsultaDAO();
            boolean removido = dao.remover(id);
            if (!removido)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Consulta não encontrada para exclusão.")
                        .build();
            return Response.ok("Mensagem: Consulta removida com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao remover consulta: " + e.getMessage())
                    .build();
        }
    }
}
