package br.com.fiap.beans;

public class Agendamento {
    private int id;
    private String status;
    private Paciente paciente;

    public Agendamento() {}

    public Agendamento(int id, String status, Paciente paciente) {
        this.id = id;
        this.status = status;
        this.paciente = paciente;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Paciente getPaciente() { return paciente; }
    public void setPaciente(Paciente paciente) { this.paciente = paciente; }

    public int getIdPaciente() {
        return (paciente != null) ? paciente.getId() : 0;
    }

    public void setIdPaciente(int idPaciente) {
        if (this.paciente == null) this.paciente = new Paciente();
        this.paciente.setId(idPaciente);
    }

    @Override
    public String toString() {
        return "\nAgendamento ID: " + id +
                "\nStatus: " + status +
                "\nPaciente: " + (paciente != null ? paciente.getNome() : "Não definido");
    }
}
