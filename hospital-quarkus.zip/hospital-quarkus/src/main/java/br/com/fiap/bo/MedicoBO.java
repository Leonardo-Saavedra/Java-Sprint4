package br.com.fiap.bo;

import br.com.fiap.beans.Medico;
import br.com.fiap.dao.MedicoDAO;
import java.util.List;

public class MedicoBO {

    private MedicoDAO medicoDAO;

    public MedicoBO() throws Exception {
        medicoDAO = new MedicoDAO();
    }

    public List<Medico> listar() throws Exception {
        return medicoDAO.listar();
    }

    public Medico buscarPorId(int id) throws Exception {
        return medicoDAO.buscarPorId(id);
    }

    public void salvar(Medico medico) throws Exception {
        if (medico.getNome() == null || medico.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do médico é obrigatório.");
        }
        medicoDAO.inserir(medico);
    }

    public boolean atualizar(int id, Medico medico) throws Exception {
        return medicoDAO.atualizar(id, medico);
    }

    public boolean deletar(int id) throws Exception {
        return medicoDAO.remover(id);
    }
}
