package br.com.fiap.dao;

import br.com.fiap.beans.Medico;
import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicoDAO {

    public int inserir(Medico medico) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO medico (id_medico, nm_medico, num_crm, ds_email) VALUES (?, ?, ?, ?)";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, medico.getId());
            ps.setString(2, medico.getNome());
            ps.setString(3, medico.getCrm());
            ps.setString(4, medico.getEmail());
            return ps.executeUpdate();
        }
    }

    public List<Medico> listar() throws SQLException, ClassNotFoundException {
        List<Medico> lista = new ArrayList<>();
        String sql = "SELECT id_medico, nm_medico, num_crm, ds_email FROM medico";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Medico m = new Medico(
                        rs.getInt("id_medico"),
                        rs.getString("nm_medico"),
                        rs.getString("num_crm"),
                        rs.getString("ds_email")
                );
                lista.add(m);
            }
        }
        return lista;
    }

    public Medico buscarPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id_medico, nm_medico, num_crm, ds_email FROM medico WHERE id_medico = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Medico(
                            rs.getInt("id_medico"),
                            rs.getString("nm_medico"),
                            rs.getString("num_crm"),
                            rs.getString("ds_email")
                    );
                }
            }
        }
        return null;
    }

    public boolean atualizar(int id, Medico medicoAtualizado) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE medico SET nm_medico = ?, num_crm = ?, ds_email = ? WHERE id_medico = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, medicoAtualizado.getNome());
            ps.setString(2, medicoAtualizado.getCrm());
            ps.setString(3, medicoAtualizado.getEmail());
            ps.setInt(4, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean remover(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM medico WHERE id_medico = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
