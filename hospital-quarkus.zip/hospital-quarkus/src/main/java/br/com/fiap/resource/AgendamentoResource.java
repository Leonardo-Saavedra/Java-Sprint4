package br.com.fiap.resource;

import br.com.fiap.beans.Agendamento;
import br.com.fiap.dao.AgendamentoDAO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/agendamentos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AgendamentoResource {

    @GET
    public Response listar() {
        try {
            AgendamentoDAO dao = new AgendamentoDAO();
            List<Agendamento> lista = dao.listar();
            return Response.ok(lista).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao listar agendamentos: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            AgendamentoDAO dao = new AgendamentoDAO();
            Agendamento agendamento = dao.buscarPorId(id);
            if (agendamento == null)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Agendamento não encontrado.")
                        .build();
            return Response.ok(agendamento).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao buscar agendamento: " + e.getMessage())
                    .build();
        }
    }

    @POST
    public Response inserir(Agendamento agendamento) {
        try {
            AgendamentoDAO dao = new AgendamentoDAO();
            dao.inserir(agendamento);
            return Response.status(Response.Status.CREATED)
                    .entity("Mensagem: Agendamento inserido com sucesso!")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao inserir agendamento: " + e.getMessage())
                    .build();
        }
    }

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") int id, Agendamento agendamento) {
        try {
            AgendamentoDAO dao = new AgendamentoDAO();
            agendamento.setId(id);
            boolean atualizado = dao.atualizar(id, agendamento);

            if (!atualizado)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Agendamento não encontrado.")
                        .build();

            return Response.ok("Mensagem: Agendamento atualizado com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao atualizar agendamento: " + e.getMessage())
                    .build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response remover(@PathParam("id") int id) {
        try {
            AgendamentoDAO dao = new AgendamentoDAO();
            boolean removido = dao.remover(id);
            if (!removido)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Agendamento não encontrado para exclusão.")
                        .build();
            return Response.ok("Mensagem: Agendamento removido com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao remover agendamento: " + e.getMessage())
                    .build();
        }
    }
}
