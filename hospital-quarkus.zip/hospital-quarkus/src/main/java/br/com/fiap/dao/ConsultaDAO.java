package br.com.fiap.dao;

import br.com.fiap.beans.Consulta;
import br.com.fiap.beans.Medico;
import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO {

    public int inserir(Consulta consulta) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO consulta (id_consulta, ds_tipo, dt_dia, id_medico) VALUES (?, ?, ?, ?)";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, consulta.getId());
            ps.setString(2, consulta.getTipo());
            ps.setDate(3, Date.valueOf(consulta.getData()));
            ps.setInt(4, consulta.getIdMedico());
            return ps.executeUpdate();
        }
    }

    public List<Consulta> listar() throws SQLException, ClassNotFoundException {
        List<Consulta> lista = new ArrayList<>();
        String sql = "SELECT id_consulta, ds_tipo, dt_dia, id_medico FROM consulta";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Consulta c = new Consulta();
                c.setId(rs.getInt("id_consulta"));
                c.setTipo(rs.getString("ds_tipo"));
                Date d = rs.getDate("dt_dia");
                c.setData(d != null ? d.toLocalDate() : null);
                int idMed = rs.getInt("id_medico");
                if (!rs.wasNull()) {
                    c.setIdMedico(idMed);
                }
                lista.add(c);
            }
        }
        return lista;
    }

    public Consulta buscarPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id_consulta, ds_tipo, dt_dia, id_medico FROM consulta WHERE id_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Consulta c = new Consulta();
                    c.setId(rs.getInt("id_consulta"));
                    c.setTipo(rs.getString("ds_tipo"));
                    Date d = rs.getDate("dt_dia");
                    c.setData(d != null ? d.toLocalDate() : null);
                    c.setIdMedico(rs.getInt("id_medico"));
                    return c;
                }
            }
        }
        return null;
    }

    public boolean atualizar(int id, Consulta consulta) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE consulta SET ds_tipo = ?, dt_dia = ?, id_medico = ? WHERE id_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, consulta.getTipo());
            ps.setDate(2, Date.valueOf(consulta.getData()));
            ps.setInt(3, consulta.getIdMedico());
            ps.setInt(4, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean remover(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM consulta WHERE id_consulta = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
