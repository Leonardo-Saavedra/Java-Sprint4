package br.com.fiap.resource;

import br.com.fiap.beans.Paciente;
import br.com.fiap.dao.PacienteDAO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/pacientes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PacienteResource {

    @GET
    public Response listar() {
        try {
            PacienteDAO dao = new PacienteDAO();
            List<Paciente> lista = dao.listar();
            return Response.ok(lista).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao listar pacientes: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            PacienteDAO dao = new PacienteDAO();
            Paciente paciente = dao.buscarPorId(id);
            if (paciente == null)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Paciente não encontrado.")
                        .build();
            return Response.ok(paciente).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao buscar paciente: " + e.getMessage())
                    .build();
        }
    }

    @POST
    public Response inserir(Paciente paciente) {
        try {
            PacienteDAO dao = new PacienteDAO();
            dao.inserir(paciente);
            return Response.status(Response.Status.CREATED)
                    .entity("Mensagem: Paciente inserido com sucesso!")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao inserir paciente: " + e.getMessage())
                    .build();
        }
    }

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") int id, Paciente paciente) {
        try {
            PacienteDAO dao = new PacienteDAO();
            paciente.setId(id);
            boolean atualizado = dao.atualizar(id, paciente);

            if (!atualizado)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Paciente não encontrado.")
                        .build();

            return Response.ok("Mensagem: Paciente atualizado com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao atualizar paciente: " + e.getMessage())
                    .build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response remover(@PathParam("id") int id) {
        try {
            PacienteDAO dao = new PacienteDAO();
            boolean removido = dao.remover(id);
            if (!removido)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Paciente não encontrado para exclusão.")
                        .build();
            return Response.ok("Mensagem: Paciente removido com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao remover paciente: " + e.getMessage())
                    .build();
        }
    }
}
