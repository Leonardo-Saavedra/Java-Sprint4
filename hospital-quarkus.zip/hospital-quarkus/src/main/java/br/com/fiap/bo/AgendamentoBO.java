package br.com.fiap.bo;

import br.com.fiap.beans.Agendamento;
import br.com.fiap.dao.AgendamentoDAO;
import java.util.List;

public class AgendamentoBO {
    private AgendamentoDAO dao;

    public List<Agendamento> listar() throws Exception {
        dao = new AgendamentoDAO();
        return dao.listar();
    }

    public Agendamento buscarPorId(int id) throws Exception {
        dao = new AgendamentoDAO();
        return dao.buscarPorId(id);
    }

    public void salvar(Agendamento a) throws Exception {
        dao = new AgendamentoDAO();
        dao.inserir(a);
    }

    public boolean atualizar(int id, Agendamento a) throws Exception {
        dao = new AgendamentoDAO();
        return dao.atualizar(id, a);
    }

    public boolean deletar(int id) throws Exception {
        dao = new AgendamentoDAO();
        return dao.remover(id);
    }
}
