package br.com.fiap.resource;

import br.com.fiap.beans.TeleConsulta;
import br.com.fiap.dao.TeleConsultaDAO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/teleconsultas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TeleConsultaResource {

    @GET
    public Response listar() {
        try {
            TeleConsultaDAO dao = new TeleConsultaDAO();
            List<TeleConsulta> lista = dao.listar();
            return Response.ok(lista).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao listar teleconsultas: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            TeleConsultaDAO dao = new TeleConsultaDAO();
            TeleConsulta teleConsulta = dao.buscarPorId(id);
            if (teleConsulta == null)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: TeleConsulta não encontrada.")
                        .build();
            return Response.ok(teleConsulta).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao buscar TeleConsulta: " + e.getMessage())
                    .build();
        }
    }

    @POST
    public Response inserir(TeleConsulta teleConsulta) {
        try {
            TeleConsultaDAO dao = new TeleConsultaDAO();
            dao.inserir(teleConsulta);
            return Response.status(Response.Status.CREATED)
                    .entity("Mensagem: TeleConsulta inserida com sucesso!")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao inserir TeleConsulta: " + e.getMessage())
                    .build();
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response atualizar(@PathParam("id") int id, TeleConsulta teleConsulta) {
        try {
            TeleConsultaDAO dao = new TeleConsultaDAO();
            teleConsulta.setId(id);
            boolean atualizado = dao.atualizar(id, teleConsulta);

            if (!atualizado)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: TeleConsulta não encontrada.")
                        .build();

            return Response.ok("Mensagem: TeleConsulta atualizada com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao atualizar TeleConsulta: " + e.getMessage())
                    .build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response remover(@PathParam("id") int id) {
        try {
            TeleConsultaDAO dao = new TeleConsultaDAO();
            boolean removido = dao.remover(id);
            if (!removido)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: TeleConsulta não encontrada para exclusão.")
                        .build();
            return Response.ok("Mensagem: TeleConsulta removida com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao remover TeleConsulta: " + e.getMessage())
                    .build();
        }
    }
}
