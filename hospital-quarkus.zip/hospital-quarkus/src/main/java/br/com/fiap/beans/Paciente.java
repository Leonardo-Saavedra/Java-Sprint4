package br.com.fiap.beans;

import java.time.LocalDate;
import java.time.Period;

public class Paciente {
    private int id;
    private String nome;
    private String telefone;
    private LocalDate dataNascimento;
    private Medico medico;

    public Paciente() {}

    public Paciente(int id, String nome, String telefone, LocalDate dataNascimento, Medico medico) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.medico = medico;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public LocalDate getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(LocalDate dataNascimento) { this.dataNascimento = dataNascimento; }

    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }

    public int calcularIdade() {
        if (dataNascimento == null) return 0;
        return Period.between(dataNascimento, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "\nPaciente: " + nome +
                "\nID: " + id +
                "\nTelefone: " + telefone +
                "\nData Nascimento: " + dataNascimento +
                "\nIdade: " + calcularIdade() +
                "\nMedico: " + (medico != null ? medico.getNome() : "Não definido");
    }
}
