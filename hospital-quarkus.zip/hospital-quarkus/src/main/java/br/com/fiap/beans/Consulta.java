package br.com.fiap.beans;

import java.time.LocalDate;

public class Consulta {
    private int id;
    private String tipo;
    private LocalDate data;
    private Medico medico;

    public Consulta() {}

    public Consulta(int id, String tipo, LocalDate data, Medico medico) {
        this.id = id;
        this.tipo = tipo;
        this.data = data;
        this.medico = medico;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }

    public int getIdMedico() {
        return (medico != null) ? medico.getId() : 0;
    }

    public void setIdMedico(int idMedico) {
        if (this.medico == null) this.medico = new Medico();
        this.medico.setId(idMedico);
    }

    @Override
    public String toString() {
        return "\nConsulta ID: " + id +
                "\nTipo: " + tipo +
                "\nData: " + data +
                "\nMedico: " + (medico != null ? medico.getNome() : "Não definido");
    }
}
