package br.com.fiap.beans;

public class TeleConsulta {
    private int id;
    private String observacoes;
    private Medico medico;

    public TeleConsulta() {}

    public TeleConsulta(int id, String observacoes, Medico medico) {
        this.id = id;
        this.observacoes = observacoes;
        this.medico = medico;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }

    public int getIdMedico() {
        return (medico != null) ? medico.getId() : 0;
    }

    public void setIdMedico(int idMedico) {
        if (this.medico == null) this.medico = new Medico();
        this.medico.setId(idMedico);
    }

    @Override
    public String toString() {
        return "\nTeleConsulta ID: " + id +
                "\nObservacoes: " + observacoes +
                "\nMedico: " + (medico != null ? medico.getNome() : "Não definido");
    }
}
