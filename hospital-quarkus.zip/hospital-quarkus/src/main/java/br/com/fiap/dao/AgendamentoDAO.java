package br.com.fiap.dao;

import br.com.fiap.beans.Agendamento;
import br.com.fiap.beans.Paciente;
import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDAO {

    public int inserir(Agendamento a) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO agendamento (id_agendamento, ds_status, id_paciente) VALUES (?, ?, ?)";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, a.getId());
            ps.setString(2, a.getStatus());
            ps.setInt(3, a.getIdPaciente());
            return ps.executeUpdate();
        }
    }

    public List<Agendamento> listar() throws SQLException, ClassNotFoundException {
        List<Agendamento> lista = new ArrayList<>();
        String sql = "SELECT id_agendamento, ds_status, id_paciente FROM agendamento";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Agendamento a = new Agendamento();
                a.setId(rs.getInt("id_agendamento"));
                a.setStatus(rs.getString("ds_status"));
                int idPac = rs.getInt("id_paciente");
                if (!rs.wasNull()) a.setIdPaciente(idPac);
                lista.add(a);
            }
        }
        return lista;
    }

    public Agendamento buscarPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id_agendamento, ds_status, id_paciente FROM agendamento WHERE id_agendamento = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Agendamento a = new Agendamento();
                    a.setId(rs.getInt("id_agendamento"));
                    a.setStatus(rs.getString("ds_status"));
                    a.setIdPaciente(rs.getInt("id_paciente"));
                    return a;
                }
            }
        }
        return null;
    }

    public boolean atualizar(int id, Agendamento a) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE agendamento SET ds_status = ?, id_paciente = ? WHERE id_agendamento = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, a.getStatus());
            ps.setInt(2, a.getIdPaciente());
            ps.setInt(3, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean remover(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM agendamento WHERE id_agendamento = ?";
        try (Connection con = new ConexaoFactory().conexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
