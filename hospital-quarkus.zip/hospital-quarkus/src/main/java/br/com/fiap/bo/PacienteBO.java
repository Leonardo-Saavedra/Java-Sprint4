package br.com.fiap.bo;

import br.com.fiap.beans.Paciente;
import br.com.fiap.dao.PacienteDAO;
import java.util.List;

public class PacienteBO {

    private final PacienteDAO dao = new PacienteDAO();

    public List<Paciente> listar() throws Exception {
        return dao.listar();
    }

    public Paciente buscarPorId(int id) throws Exception {
        return dao.buscarPorId(id);
    }

    public void salvar(Paciente paciente) throws Exception {
        if (paciente.getNome() == null || paciente.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do paciente é obrigatório!");
        }
        dao.inserir(paciente);
    }

    public boolean atualizar(int id, Paciente paciente) throws Exception {
        return dao.atualizar(id, paciente);
    }

    public boolean deletar(int id) throws Exception {
        return dao.remover(id);
    }
}
