package br.com.fiap.bo;

import br.com.fiap.beans.Consulta;
import br.com.fiap.dao.ConsultaDAO;
import java.util.List;

public class ConsultaBO {
    private ConsultaDAO dao;

    public List<Consulta> listar() throws Exception {
        dao = new ConsultaDAO();
        return dao.listar();
    }

    public Consulta buscarPorId(int id) throws Exception {
        dao = new ConsultaDAO();
        return dao.buscarPorId(id);
    }

    public void salvar(Consulta consulta) throws Exception {
        dao = new ConsultaDAO();
        dao.inserir(consulta);
    }

    public boolean atualizar(int id, Consulta consulta) throws Exception {
        dao = new ConsultaDAO();
        return dao.atualizar(id, consulta);
    }

    public boolean deletar(int id) throws Exception {
        dao = new ConsultaDAO();
        return dao.remover(id);
    }
}
