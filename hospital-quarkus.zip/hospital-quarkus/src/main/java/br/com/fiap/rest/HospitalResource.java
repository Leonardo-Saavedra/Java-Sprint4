package br.com.fiap.rest;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/hospital")
public class HospitalResource {

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String helloHospital() {
        return "API do Hospital Quarkus funcionando com sucesso!";
    }
}
