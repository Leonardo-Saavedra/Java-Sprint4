package br.com.fiap.resource;

import br.com.fiap.beans.Medico;
import br.com.fiap.dao.MedicoDAO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/medicos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MedicoResource {

    @GET
    public Response listar() {
        try {
            MedicoDAO dao = new MedicoDAO();
            List<Medico> lista = dao.listar();
            return Response.ok(lista).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao listar médicos: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            MedicoDAO dao = new MedicoDAO();
            Medico medico = dao.buscarPorId(id);
            if (medico == null)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Médico não encontrado.")
                        .build();
            return Response.ok(medico).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao buscar médico: " + e.getMessage())
                    .build();
        }
    }

    @POST
    public Response inserir(Medico medico) {
        try {
            MedicoDAO dao = new MedicoDAO();
            dao.inserir(medico);
            return Response.status(Response.Status.CREATED)
                    .entity("Mensagem: Médico inserido com sucesso!")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao inserir médico: " + e.getMessage())
                    .build();
        }
    }

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") int id, Medico medico) {
        try {
            MedicoDAO dao = new MedicoDAO();
            medico.setId(id);
            boolean atualizado = dao.atualizar(id, medico);

            if (!atualizado)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Médico não encontrado.")
                        .build();

            return Response.ok("Mensagem: Médico atualizado com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao atualizar médico: " + e.getMessage())
                    .build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response remover(@PathParam("id") int id) {
        try {
            MedicoDAO dao = new MedicoDAO();
            boolean removido = dao.remover(id);
            if (!removido)
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("Mensagem: Médico não encontrado para exclusão.")
                        .build();
            return Response.ok("Mensagem: Médico removido com sucesso!").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Erro: Erro ao remover médico: " + e.getMessage())
                    .build();
        }
    }
}
